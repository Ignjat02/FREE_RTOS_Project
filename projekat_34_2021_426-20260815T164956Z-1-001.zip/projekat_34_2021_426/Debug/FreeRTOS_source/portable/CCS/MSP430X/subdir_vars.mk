################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
ASM_SRCS += \
C:/Users/Ignjat/Desktop/ФАКУЛТЕТ/MSP430_FreeRTOS-master/MSP430_FreeRTOS-master/Examples/common/FreeRTOS_source/portable/CCS/MSP430X/portext.asm 

C_SRCS += \
C:/Users/Ignjat/Desktop/ФАКУЛТЕТ/MSP430_FreeRTOS-master/MSP430_FreeRTOS-master/Examples/common/FreeRTOS_source/portable/CCS/MSP430X/port.c 

C_DEPS += \
./FreeRTOS_source/portable/CCS/MSP430X/port.d 

OBJS += \
./FreeRTOS_source/portable/CCS/MSP430X/port.obj \
./FreeRTOS_source/portable/CCS/MSP430X/portext.obj 

ASM_DEPS += \
./FreeRTOS_source/portable/CCS/MSP430X/portext.d 

OBJS__QUOTED += \
"FreeRTOS_source\portable\CCS\MSP430X\port.obj" \
"FreeRTOS_source\portable\CCS\MSP430X\portext.obj" 

C_DEPS__QUOTED += \
"FreeRTOS_source\portable\CCS\MSP430X\port.d" 

ASM_DEPS__QUOTED += \
"FreeRTOS_source\portable\CCS\MSP430X\portext.d" 

C_SRCS__QUOTED += \
"C:/Users/Ignjat/Desktop/ФАКУЛТЕТ/MSP430_FreeRTOS-master/MSP430_FreeRTOS-master/Examples/common/FreeRTOS_source/portable/CCS/MSP430X/port.c" 

ASM_SRCS__QUOTED += \
"C:/Users/Ignjat/Desktop/ФАКУЛТЕТ/MSP430_FreeRTOS-master/MSP430_FreeRTOS-master/Examples/common/FreeRTOS_source/portable/CCS/MSP430X/portext.asm" 


