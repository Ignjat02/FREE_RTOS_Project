################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/Users/Ignjat/Desktop/ФАКУЛТЕТ/MSP430_FreeRTOS-master/MSP430_FreeRTOS-master/Examples/common/drivers/MSP430F5xx_6xx/pmm.c \
C:/Users/Ignjat/Desktop/ФАКУЛТЕТ/MSP430_FreeRTOS-master/MSP430_FreeRTOS-master/Examples/common/drivers/MSP430F5xx_6xx/ucs.c 

C_DEPS += \
./drivers/MSP430F5xx_6xx/pmm.d \
./drivers/MSP430F5xx_6xx/ucs.d 

OBJS += \
./drivers/MSP430F5xx_6xx/pmm.obj \
./drivers/MSP430F5xx_6xx/ucs.obj 

OBJS__QUOTED += \
"drivers\MSP430F5xx_6xx\pmm.obj" \
"drivers\MSP430F5xx_6xx\ucs.obj" 

C_DEPS__QUOTED += \
"drivers\MSP430F5xx_6xx\pmm.d" \
"drivers\MSP430F5xx_6xx\ucs.d" 

C_SRCS__QUOTED += \
"C:/Users/Ignjat/Desktop/ФАКУЛТЕТ/MSP430_FreeRTOS-master/MSP430_FreeRTOS-master/Examples/common/drivers/MSP430F5xx_6xx/pmm.c" \
"C:/Users/Ignjat/Desktop/ФАКУЛТЕТ/MSP430_FreeRTOS-master/MSP430_FreeRTOS-master/Examples/common/drivers/MSP430F5xx_6xx/ucs.c" 


